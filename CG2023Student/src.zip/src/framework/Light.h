//
//  Light.h
//  ComputerGraphics
//
//  Created by Manvir Kaur on 10/03/23.
//

#ifndef Light_h
#define Light_h


class Light{
    
    public:
    Vector3 position, Id, Is;
};
#endif /* Light_h */
