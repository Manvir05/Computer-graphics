//
//  Light.cpp
//  ComputerGraphics
//
//  Created by Manvir Kaur on 10/03/23.
//

#include <stdio.h>

