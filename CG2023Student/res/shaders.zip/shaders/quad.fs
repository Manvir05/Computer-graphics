varying vec2 v_uv;
uniform float u_time;

uniform int option;
uniform float u_aspect;
uniform sampler2D u_texture;

void main()
{
    float x = v_uv.x;
    float y = v_uv.y;

    vec4 final_color = vec4(0.0, 0.0, 0.0, 0.0);
    vec4 texture_color = texture2D(u_texture, v_uv);
    
   
}
