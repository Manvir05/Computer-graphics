varying vec2 v_uv;
uniform float u_time;
uniform int option;

uniform sampler2D u_texture;

void main()
{
    float x = v_uv.x;
    float y = v_uv.y;

    vec4 final_color = vec4(0.0);
    vec4 texture_color = texture2D(u_texture, v_uv);
    
    
    if(option==0){
        final_color = vec4(vec3((texture_color.r + texture_color.g + texture_color.b + sin(u_time))/3.0), 1.0);
    }
    
    if(option==1){
        final_color = 1.0-texture_color + sin(u_time);
    }
    if(option==2){
        float f = (texture_color.r+texture_color.g+texture_color.b + sin(u_time))/3.0;
        texture_color = vec4(vec3(f),1.0);
        final_color = step(0.5, texture_color);
    }
    if(option==3){
        final_color = vec4(1.0-texture_color.b + sin(u_time),texture_color.r + sin(u_time), texture_color.g/2.0+ sin(u_time), 1.0);
        
    }
    if(option == 4){
        vec4 color = vec4(0.0);
        for (float i = 0.0; i <= 1.0; i += 1.0) {
            for (float j = 0.0; j <= 1.0; j += 1.0) {
                vec2 offset = vec2(i, j)*sin(u_time);
                vec2 uv = v_uv + offset*0.003 ;
                color += texture2D(u_texture, uv);
            }
        }
        final_color= color/7.0;
    }
    if(option == 5){
        //distance from center of the screen
        float vignette = clamp(1.25 - length(v_uv - vec2(0.5, 0.5)) *2.0+ sin(u_time), 0.0, 1.0);
        final_color = vec4(vec3(texture_color.rgb*vignette*0.5), 1.0);
    }
    gl_FragColor = final_color;
}

