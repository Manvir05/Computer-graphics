varying vec2 v_uv;
uniform float u_time;

uniform int option;
uniform float u_aspect;

void main()
{
    
    float x = v_uv.x;
    float y = v_uv.y;

    vec4 final_color = vec4(0.0, 0.0, 0.0, 0.0);
    
    vec3 color_red = vec3(1.0,0,0 );
    vec3 color_blue = vec3(0, 0, 1.0);
    vec3 color_green = vec3(0,1.0,0);
    vec3 color_white = vec3(1.0,1.0,1.0);
    vec3 color_black = vec3(0,0,0);

    if(option==0){
        vec3 color_red = vec3(abs(cos(u_time)),0.0,0.0);
        vec3 color_blue = vec3(0.0,0.0,abs(sin(u_time)));

        final_color = vec4((1.0-x)*color_blue + x*color_red,1.0);
        
    }
    if(option==1){
        color_white = vec3(abs(sin(u_time)));
        //final_color = vec4((pow(2.0*(x-0.5),2.0) + pow(2.0*(y-0.5),2.0) - pow(0.05,2.0))*color_white,1.0);
        final_color = vec4(vec3(distance(vec2(0.5),v_uv))*color_white,1.0);
    }
    if(option==2){
        color_blue = vec3(0.0, 0.0, 1.0);
        color_red = vec3(1.0,0.0,0.0 );
        float Y = sin(15.0*3.14*y/u_aspect);
        float X = sin(20.0*3.14*x/u_aspect);
        final_color = vec4(vec3(Y,0.0,X), 1.0);
    }
    if(option==3){
        vec3 color_green = vec3(0.0,abs(cos(u_time)),0.0);
        color_red = vec3(abs(cos(u_time)),0.0,0.0 );
        
        vec3 color1 = mix(color_green, color_black,(1.0- y));
        vec3 color2 = mix(color_red, color_black,(1.0- x));
        float a = floor(15.0*x)/15.0;
        float b = floor((15.0/u_aspect)*y)/(15.0/u_aspect);
        final_color = vec4(vec3(a,b,0.0), 1.0);
    }
    
    if(option==4){
        vec4 green = vec4(color_green, 1.0);
        final_color = step((sin(x*5.7 + u_time*2.0)+2.0)/4.0,y)*(1.0-y)*green + step((sin(x*5.7 + 3.141592 + u_time*2.0)+2.0)/4.0,(1.0-y))*y*green;
    }
    if(option==5){
        
        float X = floor(20.0*x);
        float Y = floor((20.0/u_aspect)*y);
        float mod_x= mod(X, 2.0);
        float mod_y = mod(Y,2.0);
        
        final_color = vec4(vec3(mod(mod_x+mod_y , 2.0)), 1.0);
    }
   
    gl_FragColor = final_color;
   
}
