varying vec2 v_uv;
uniform float u_time;
uniform int option;
uniform float u_aspect;

uniform sampler2D u_texture;

void main()
{
    float x = v_uv.x;
    float y = v_uv.y;

    vec4 final_color = vec4(0.0, 0.0, 0.0, 0.0);
    vec4 texture_color = texture2D(u_texture, v_uv);
    
    if(option==0){
        vec2 uv = (v_uv * 2.0 - 1.0 )*sin(u_time);  // map to [-1, 1] range// adjust for texture aspect ratio
        uv /= 2.0;  // map back to [0, 1] range

        vec2 p =  mod(uv *5.0, 2.0) - 1.0;  // create four rectangles

        final_color = texture2D(u_texture, (p+1.0)/2.0);

    }
    if(option==1){
        vec2 pixsize = vec2(0.015)*mod(u_time,3.0);
        vec2 pixcoord = floor(v_uv/ pixsize) * pixsize;
        final_color = texture2D(u_texture, pixcoord);
        

    }
    
    gl_FragColor = final_color;
}

