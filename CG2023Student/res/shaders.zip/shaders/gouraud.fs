varying vec3 v_vertex_color;

void main()
{
    gl_FragColor = vec4(v_vertex_color, 1.0);
}
