uniform vec3 u_Id;
uniform vec3 u_Is;
uniform vec3 u_Ia;
varying vec3 v_world_position;
varying vec3 v_world_normal;

uniform vec3 u_position;
uniform vec3 u_eye;
uniform vec3 u_ka;
uniform vec3 u_kd;
uniform vec3 u_ks;

uniform float u_alpha;

uniform sampler2D u_specular;
uniform sampler2D u_normal;
uniform mat4 u_modelMatrix;
uniform vec3 u_flag;
varying vec2 v_uv;
void main()
{
    vec3 kd = u_kd;
    vec3 ka = u_ka;
    vec3 ks = u_ks;
    
    vec4 specular_color = texture2D(u_specular, v_uv);
    vec4 normal_color = texture2D(u_normal, v_uv);
    vec3 N = normalize(v_world_normal);
    
    if(u_flag.x == 1.0){
        ka *= specular_color.rgb ;
        kd = specular_color.rgb ;
        ks = vec3(specular_color.a);
    }
    if(u_flag.y == 1.0){
        N = normalize(normal_color.rgb*2.0-1.0); //from -1 to 1, before 0 to 1
        N = (u_modelMatrix * vec4( N.xyz, 0.0)).xyz; //to world
        float mix_factor = 0.5;
        N = mix(v_world_normal, N, mix_factor);
    }
   
    vec3 L = normalize(u_position - v_world_position);
    vec3 V = normalize(u_eye-v_world_position);
    vec3 R = reflect(-L, N);
    
    vec3 Ambient = ka * u_Ia;
    vec3 Diffuse = kd * clamp(dot(N, L), 0.0,1.0) * u_Id;
    vec3 Specular = ks * pow(clamp(dot(R, V), 0.0,1.0), u_alpha) * u_Is;
   
    gl_FragColor = vec4((Ambient + Diffuse + Specular) , 1.0);
}
